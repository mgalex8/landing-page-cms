var fvdSingleDownloader = {
	noYoutube: true,
	noWelcome: false
};