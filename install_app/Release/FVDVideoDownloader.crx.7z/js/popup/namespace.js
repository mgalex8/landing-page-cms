var fvdSingleDownloader = {
	noYoutube: chrome.extension.getBackgroundPage().fvdSingleDownloader.noYoutube
};