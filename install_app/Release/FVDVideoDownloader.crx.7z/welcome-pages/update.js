document.addEventListener("DOMContentLoaded", function(){
	if( navigator.appVersion.indexOf("Mac OS X") != -1 ){
		
		document.getElementsByClassName( "converterAd" )[0].style.display = "none";
		document.getElementsByClassName( "macOsAd" )[0].style.display = "block";
	}	
	

});

