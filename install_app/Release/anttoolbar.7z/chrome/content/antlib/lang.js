// 
//  lang.js
//  firefox
//  
//  Created by Zak on 2008-07-14.
//  Contributor Brian King
//  Copyright 2008-2012 Ant.com. All rights reserved.
// 

/**
 * Handle localization of JS strings
 */
var AntLang =
{
	/**
	 * Get a pointer to the string bundle object
	 */
	get lang()
	{
	    return AntLib.ob("antbarStrings");
	},

	/**
	 * Return the string corresponding to the given symbol
	 * @param str       The symbol string to translate
	 */
	getString: function (str)
	{
	    return this.lang.getString(str);
	},

	/**
	 * Return the formated string corresponding to the given symbol
	 * @param fmt       The format string (printf style)
	 */
	getFormatString: function (fmt)
	{
            return this.lang.getFormattedString( fmt, Array.prototype.slice.call(arguments, 1) );
	}
}

