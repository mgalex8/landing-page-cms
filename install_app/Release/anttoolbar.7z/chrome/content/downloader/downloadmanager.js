// 
//  downloadmanager.js
//  firefox
//  
//  Created by Zak on 2008-06-17.
//  Contributor Brian King
//  Copyright 2008-2012 Ant.com. All rights reserved.
// 

Components.utils.import("resource://gre/modules/XPCOMUtils.jsm");

function AntDownloadListener() {}

AntDownloadListener.prototype = {
  //////////////////////////////////////////////////////////////////////////////
  //// nsISupports

  QueryInterface: XPCOMUtils.generateQI([Components.interfaces.nsIDownloadProgressListener]),

  //////////////////////////////////////////////////////////////////////////////
  //// nsIDownloadProgressListener

  flvLink: null,
  dlMgr: null,
  targetDownload: null,
  dest: null,

  onDownloadStateChange: function(aState, aDownload) {
    var state = aDownload.state;
    AntLib.toLog("AntDownloadListener: onDownloadStateChange state = "+state);

    switch (state) {
      case AntLib._CI.nsIDownloadManager.DOWNLOAD_FAILED:
      case AntLib._CI.nsIDownloadManager.DOWNLOAD_CANCELED:
      case AntLib._CI.nsIDownloadManager.DOWNLOAD_BLOCKED_PARENTAL:
      case AntLib._CI.nsIDownloadManager.DOWNLOAD_DIRTY: {
        if (aDownload == this.targetDownload) {
          AntLib.toLog("AntDownloadListener: removing listener");
          this.dlMgr.removeListener(this);
        }
        break;
      }
    }
  },
  onProgressChange: function(){},
  onSecurityChange: function(){},
  onStateChange: function(webProgress, request, stateFlags, status, download) {

    if ( download == this.targetDownload
         && status == AntLib._CI.nsIDownloadManager.DOWNLOAD_DOWNLOADING
         && (stateFlags & AntLib._CI.nsIWebProgressListener.STATE_STOP) ) {

                                     
      AntRPC.download(this.flvLink);

      var path = this.dest.path;
      try {
   
        AntStorage.beginTransaction();
        AntStorage.addPlaylist( '' );
        AntStorage.addVideoRecord( AntHash.getFileHash(path),
                                   this.flvLink.name,
                                   path,
                                   this.flvLink.webPage,
                                   this.flvLink.url.spec,
                                   this.flvLink.origin,
                                   0, //TODO: add duration here
                                   download.targetFile.fileSize,
                                   '',
                                   0,
                                   0,
                                   (new Date()).getTime()
                                  );
      }
      finally {

        AntLib.toLog("AntDownloadListener: Download cleanup");
        try {
          AntStorage.endTransaction();
          var playerWnd = AntBar.getPlayerWnd();
          if (playerWnd)
            playerWnd.AntPlayer.updateTreeContent();
        }
        catch(e) {
          AntLib.toLog("AntDownloadListener: Download cleanup error: " + e);
        }

        // Keep this outside the try block as it is essential we reach this and clean up the listener
        this.dlMgr.removeListener(this);
      }
    }
  }

};

AntDownloader = function() {
  this.maxPath = 259; //MAX_PATH = 259 + null terminating character
};

AntDownloader.prototype.download = function(flvlink, dest)
{
    try
    {
        var ioService = AntLib.CCSV("@mozilla.org/network/io-service;1", "nsIIOService");
        var s_uri = flvlink.url;
        var t_uri = ioService.newFileURI(dest);
        var nsIWBP = AntLib.CI("nsIWebBrowserPersist");
        var browserPersist = AntLib.CCIN('@mozilla.org/embedding/browser/nsWebBrowserPersist;1', "nsIWebBrowserPersist");
        this.dlMgr = AntLib.CCSV('@mozilla.org/download-manager;1', "nsIDownloadManager");
        var flags =
            nsIWBP.PERSIST_FLAGS_NO_CONVERSION
            | nsIWBP.PERSIST_FLAGS_REPLACE_EXISTING_FILES
            | nsIWBP.PERSIST_FLAGS_CLEANUP_ON_FAILURE
	    | nsIWBP.PERSIST_FLAGS_BYPASS_CACHE;

        browserPersist.persistFlags = flags;

        /**
         * Add the download to the downloader window
         */
        
        var ret =
            this.dlMgr.addDownload(
                0                                 // aDownloadType:short = nsIDownloadManager.DOWNLOAD_TYPE_DOWNLOAD
                , s_uri                           // aSource:nsIURI
                , t_uri                           // aTarget:nsIURI
                , flvlink.name.replace(/_/g, " ") // aDisplayName:AString
                , null                            // aMIMEInfo:nsIMIMEInfo
                , null                            // aStartTime:PRTime
                , null                            // aTempFile:nsILocalFile
                , browserPersist                  // aCancelable:nsICancelable
                , AntLib.inPrivate);              // aIsPrivate:boolean

        browserPersist.progressListener = ret;

        AntPrefs.flvToPlay = dest.path;

        var dlListener = new AntDownloadListener();
        dlListener.flvLink = flvlink;
        dlListener.dlMgr = this.dlMgr;
        dlListener.targetDownload = ret;
        dlListener.dest = dest;
        this.dlMgr.addListener(dlListener);

        AntLib.toLog("AntDownloadManager: window: " + window);
        AntLib.toLog("AntDownloadManager: window.arguments: " + window.arguments);

	var privacyContext = window.QueryInterface(Ci.nsIInterfaceRequestor)
                .getInterface(Ci.nsIWebNavigation)
		.QueryInterface(Ci.nsILoadContext);

        AntLib.toLog("AntDownloadManager: privacyContext: " + privacyContext);

        browserPersist.saveURI(
            s_uri, null, null, flvlink.postData, flvlink.header, t_uri, privacyContext);
    }
    catch (e)
    {
      alert(AntLang.getString("AntDownloadManager.DownloadError"));
      AntLib.toLog("AntDownloadManager: Download error: " + e);
    }
}

/**
 * return the movies destination folder and create it if it doesn't exist
*/
AntDownloader.prototype.getDestFolder = function () 
{
  var flvdir = AntPrefs.flvDir;
  var file;

  try
  {
    try { // requires Gecko 14
      file = AntLib.CCIN("@mozilla.org/file/local;1", "nsIFile");
      file.initWithPath(flvdir);
    }
    catch(e) {
      file = AntLib.CCIN("@mozilla.org/file/local;1", "nsILocalFile");
      file.initWithPath(flvdir);
    }

    if (!file.exists()) 
      file.create(AntLib.CI("nsIFile").DIRECTORY_TYPE, 0777);
          
    if (!file.isDirectory()) {
      alert(AntLang.getString("AntDownloadManager.InvalidDestinationFolder"));
      return null;
    }
  }
  catch (e) {
    alert(AntLang.getString("AntDownloadManager.NoFlvDir"));
    return null;
  }

  return file;
}

/*
 * returns local file object for current flv link
 * @param flvLink - flv link
 * @param bInc - inrement suffix of the file or not ( name -> name_1 -> name_2 )
 */
AntDownloader.prototype.setupFile = function(flvLink, bInc)
{
  var destFile = this.getDestFolder();
  if ( !destFile )
    return null;

  var ext = flvLink.getExtension();
  var folder_len = destFile.path.length;

  //the file format is folder\origin.name.ext
  //checking, if folder\origin..ext is less then max path
  if ( folder_len
      + 1
      + flvLink.origin.length
      + 2
      + ext.length
      > this.maxPath ) {
    AntLib.toLog( "folder name too long - " + destFile.path );
    return null;
  }

  var bCanGrow = true;
  //as we can add 1-2 symbols in incrementFlvName, so including them to calculate file name length
  var file_name_len = flvLink.origin.length + 1 + flvLink.name.length + 1 + ext.length;

  var full_len = folder_len + 1 + file_name_len;//folder\file_name.ext
  if ( full_len >= this.maxPath ) {

    bCanGrow = false;
    if ( full_len > this.maxPath ) {

      var tr_len = full_len - this.maxPath;
      flvLink.name = flvLink.name.substring(0, flvLink.name.length - tr_len); //truncating the file name
    }
  }

  if (bInc) {
    if ( !flvLink.incrementFlvName(bCanGrow) )
      return null;
  }
  var fName = AntLib.sanitize(flvLink.origin) + "." + AntLib.sanitize(flvLink.name) + "." + ext;
  AntLib.toLog( destFile.path + '\\' + fName );
  destFile.append( fName );

  return destFile;
}

/**
 * public function to download a flv from the toolbar
 * @param origin the origin web site where the movie is from e.g. youtube
 * @param url where the flv is
 * @param name of the video
 * @param doNotOpen if true the function won't open the firefox download manager
 * @return destFile.path if available else false
 */
AntDownloader.prototype.downloadFlv = function (flvLink, doNotOpen)
{
  flvLink.name = AntLib.sanitize(flvLink.name);
  flvLink.origin = AntLib.sanitize(flvLink.origin);

  var destFile = this.setupFile(flvLink, false);
  if (!destFile)
    return false;

  while (destFile.exists()) {
    destFile = this.setupFile(flvLink, true);
  }

  try {
    destFile.create(AntLib.CI("nsIFile").NORMAL_FILE_TYPE, 0777);
  }
  catch (e) {
    var nb = gBrowser.getNotificationBox();

    var acceptButton = new Object();            
    acceptButton.label = 'Change';
    acceptButton.accessKey = null;
    acceptButton.popup = null;
    acceptButton.callback = function() { AntBar.doPrefs(); };

    nb.appendNotification(
      AntLang.getString('AntBar.deniedFolderNotice'),
      'ant-denied-folder',
      'chrome://antbar/skin/favico16.png',
      nb.PRIORITY_WARNING_HIGH,
      [acceptButton] );
        
    return false;
  }

  this.download(flvLink, destFile);
  if (!doNotOpen)
    this.openDownloadWindow();
    
  return destFile.path;
}

/**
 * openDownloadWindow opens the firefox downloadManager
 */
AntDownloader.prototype.openDownloadWindow = function ()
{
  var showWhenStarting = new AntPrefService('browser.download.manager')
          .get('showWhenStarting', 'bool');
  if(showWhenStarting)
  {
    AntLib.openDialog(
        "chrome://mozapps/content/downloads/downloads.xul"
        , "Download:Manager"
        , null
        , Ci.nsIDownloadManagerUI.REASON_USER_INTERACTED);
  }
}
