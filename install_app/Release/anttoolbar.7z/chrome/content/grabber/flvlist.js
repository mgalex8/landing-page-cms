//
//  flvlist.js
//  firefox
//  
//  Created by Zak on 2008-06-12.
//  Contributor Brian King
//  Copyright 2008-2012 Ant.com. All rights reserved.
// 

function AntFlvListListener() {}

AntFlvListListener.prototype = {

  flvLink: null,

  observe: function(subject, topic, data) 
  {
      if (topic == "alertclickcallback")
          AntFlvList.download(this.flvLink);

      // Clean up the flvLink object when the notification has gone, otherwise it holds a document reference that leaks
      if (topic == "alertfinished")
          delete this.flvLink;
  }
}

var AntFlvList =
{
    /**
     * Display the notification popup box
     * @param flvLink       A flvLink object
     */
    notify: function (flvLink)
    {        
        try 
        {
            var title = AntLang.getFormatString("AntFlvList.NotificationTitle", flvLink.origin);
            var text = AntLang.getFormatString("AntFlvList.NotificationText", flvLink.name);
            var flvListener = new AntFlvListListener();
            flvListener.flvLink = flvLink;
            var alertsService = AntLib.CCSV("@mozilla.org/alerts-service;1", "nsIAlertsService");
            
            alertsService.showAlertNotification("chrome://antbar/skin/logo.png", title, text, true, "", flvListener);
        }
        catch (e)
        {
            AntLib.toLog("Cannot notify flvLInk = " + flvLink.url.spec + " ex = " + e);
        }
    },
    
    /**
     * Download a file
     * @param if true the Firefox download manager won't be opened
     */
    download: function (flvLink, doNotOpen)
    {
        var self = AntFlvList;
        var downloader = new AntDownloader();
        var path = downloader.downloadFlv(flvLink, doNotOpen);
        
        AntLib.toLog("Downloading : " + flvLink.url.spec);
    }
}
