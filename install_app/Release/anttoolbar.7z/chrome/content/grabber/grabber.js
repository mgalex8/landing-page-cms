// 
//  grabber.js
//  firefox
//  
//  Created by Zak on 2008-07-14.
//  Contributor Brian King
//  Copyright 2008-2012 Ant.com. All rights reserved.
// 

var AntGrabber =  {

    requestObserver : {
        observe : function (request, topic, data) {
            try {
                
                if ( typeof(Components) == 'undefined' )
                    return;
                
                request = request.QueryInterface(Components.interfaces["nsIHttpChannel"]);
                
                if ( request.URI.host.match( /(\.|^)ant.com/ ) ) {
                    request.setRequestHeader( 'X-Ant-UID', AntRank.UUID, false );
                    request.setRequestHeader( 'X-Ant-Agent', AntBar.getAgent(), false );
                }
            }
            catch (e) {
                AntLib.toLog("EXCEPTION : "+e);
            }
        }
    },
    queryObserver: null,

    /**
     * This method starts observing firefox requests and set a onload event
     * to be able to parse the current page and detect flvs
     */
    init: function () 
    {
        var self = AntGrabber;
        self.queryObserver = new AntQueryObserver();

        self.start();
    },
    
    /**
     * Start the grabber
     */
    start: function ()
    {
        var self = AntGrabber;
        var observerService = AntLib.CCSV("@mozilla.org/observer-service;1", "nsIObserverService");

        observerService.addObserver(self.requestObserver, "http-on-modify-request", false);
        observerService.addObserver(self.queryObserver, "http-on-examine-response", false);
        observerService.addObserver(self.queryObserver, "http-on-examine-cached-response", false);
        observerService.addObserver(self.queryObserver, "http-on-examine-merged-response", false);
    },
    
    /**
     * Called when a new flv is found
     * @param flvLink       The found flv object
     */
    foundFlvLink: function (flvLink)
    {
        AntLib.toLog("AntGrabber: New video found [Origin: "+flvLink.origin+", URL: "+flvLink.url.spec+", Name: "+flvLink.name+"]");
        
        var doc = flvLink.doc;
        var videos = AntTabMan.getAntData(doc).videos;
        
        var isDuplicated = false;
        for each( var link in videos) {
            
            if ( link.isSame(flvLink) ) {
                
                isDuplicated = true;
                break;
            }
        }
        
        if(!isDuplicated) {
            
            videos.push(flvLink);
            AntFlvUi.updateDownloadButton(doc);

            if ( AntPrefs.isNotification )
                AntFlvList.notify(flvLink);
        }
    }
};
