// 
//  queryobserver.js
//  firefox
//  
//  Created by Zak on 2008-06-09.
//  Contributor Brian King
//  Copyright 2008-2012 Ant.com. All rights reserved.
// 

/**
 * Class: Observer called when firefox download something
 * @constructor     No parameters
 */
var AntQueryObserver = function ()
{
    this.getDocByNC = function(notificationCallbacks) {
        try {
            var interfaceRequestor = AntLib.QI(notificationCallbacks, AntLib.CI("nsIInterfaceRequestor"));
            var win = AntLib.GI(interfaceRequestor, AntLib.CI("nsIDOMWindow"));
            var currentDoc = win.document;
            var rootDoc = currentDoc;
    
            while (rootDoc.defaultView.frameElement)
                rootDoc = rootDoc.defaultView.frameElement.ownerDocument;
    
            return rootDoc;
        }
        catch (e) {
            return null;
        }
    } 
    this.getDocumentByRequest = function (request)
    {
        var doc = null;
        if ( request.loadGroup )
            doc = this.getDocByNC( request.loadGroup.notificationCallbacks );
        
        if ( !doc && request.notificationCallbacks )
            doc = this.getDocByNC( request.notificationCallbacks );

        return doc;
    };
    this.getPostStream = function (request) {
        
        try {
            return request.QueryInterface( AntLib._CI['nsIUploadChannel'] ).uploadStream;
        }
        catch (e) {
            return null;
        }
    },
    /**
     * The function called by firefox, entry point of this class
     * @param request       The object containing the request params
     * @param topic         The specific event that trigger the function
     * @param data          the request data (seems to be empty)
     */
    this.observe = function (aRequest, topic, data)
    {
        if ( typeof(Components) == 'undefined' )
            return;
        
        var request = aRequest.QueryInterface(Components.interfaces["nsIHttpChannel"]);
        
        var doc = this.getDocumentByRequest(request);
        if ( !doc )
            return;
        if ( !gBrowser.getBrowserForDocument(doc) )
            return;
       
        var videoObj = AntVideoDetector.isValidVideo(request, doc);

        if ( videoObj )
        {
            var videoURI = AntLib.toURI(videoObj.url);
            if (videoObj.regrab) // re-request
            {
                function StreamListener(videoURI,service,document) {
                    this.videoURI=videoURI;
                    this.service=service;
                    this.document=document;
                    this.page = document.location.href;
                }

                StreamListener.prototype={
                    QueryInterface: function(iid) {
                        if (!iid.equals(Components.interfaces.nsISupports) && 
                            !iid.equals(Components.interfaces.nsIStreamListener)) {
                                throw Components.results.NS_ERROR_NO_INTERFACE;
                            }
                        return this;
                    },
                    onStartRequest: function(request,context) {
                        this.httpChannel=request.QueryInterface(Components.interfaces.nsIHttpChannel);
                        this.responseStatus=this.httpChannel.responseStatus;
                    },
                    onDataAvailable: function(request,context,inputStream,offset,count) { },
                    onStopRequest: function(aRequest,context,nsresult) {
                        if(this.responseStatus==200) {
                            var request = aRequest.QueryInterface(Components.interfaces["nsIHttpChannel"]);
                            var name = AntLib.safeGet(this.document, "title");
                            AntLib.toLog("FLV NAME: " + name);

                            var stream = this.service.getPostStream(request);
                            // FIXME: add score
                            var flvLink = new AntFlvLink({webPage: this.page,
                                                          origin: AntLib.getDomain(this.page),
                                                          url: videoURI,
                                                          name: name,
                                                          doc: this.document,
                                                          type: request.contentType,
                                                          length: request.contentLength,
                                                          charset: request.contentCharset,
                                                          size: request.contentLength,
                                                          postData: stream});
                            
                            AntGrabber.foundFlvLink(flvLink);  
                        }
                    }
                }

                var ios = Components.classes["@mozilla.org/network/io-service;1"]
                            .getService(Components.interfaces.nsIIOService);
                var ch = ios.newChannelFromURI(videoURI, null, null);
                ch.asyncOpen(new StreamListener(videoURI, this, doc), null);
            }
            else // get video from current request
            {

                var name = AntLib.safeGet(doc, "title");

                var page = doc.location.href;
                var stream = this.getPostStream(request);
                var size = videoObj.unkownSize ? -1 : request.contentLength;

                // FIXME: add score
                var flvLink = new AntFlvLink({webPage: page,
                                              origin: AntLib.getDomain(page),
                                              url: videoURI,
                                              name: name,
                                              doc: doc,
                                              type: request.contentType,
                                              length: request.contentLength,
                                              charset: request.contentCharset,
                                              size: size,
                                              postData: stream});
                
                AntGrabber.foundFlvLink(flvLink);
            }
        }
    };
}

